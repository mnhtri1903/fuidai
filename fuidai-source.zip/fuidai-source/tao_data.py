import json
from datasets import load_dataset

# 1. Cấu hình xác thực (BẮT BUỘC để tải nhanh hơn)
HF_TOKEN = "hf_TOKEN_CUA_BAN" 

def tai_sieu_toc():
    print("Dang ket noi voi che do Streaming (Tai den dau ghi den do)...")
    
    # Dung streaming=True de KHONG phai cho tai het 1024 file
    ds = load_dataset(
        "allenai/c4", 
        "vi", 
        split="train", 
        streaming=True, 
        token=HF_TOKEN
    )

    da_lay = 0
    gioi_han = 2000000
    
    with open("data/c4_vi_rut_gon.jsonl", "w", encoding="utf-8") as f:
        for mau in ds:
            dong_data = {"text": mau["text"]}
            f.write(json.dumps(dong_data, ensure_ascii=False) + "\n")
            
            da_lay += 1
            if da_lay % 10000 == 0:
                print(f" -> Da luu {da_lay:,} bai vao o cung...")
            
            if da_lay >= gioi_han:
                break

    print(f"Hoan tat! Da lay {da_lay:,} bai viet ma khong can tai het 110GB.")

if __name__ == "__main__":
    tai_sieu_toc()