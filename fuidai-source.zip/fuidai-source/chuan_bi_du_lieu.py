import os
import json
import random
import time
import numpy as np
from pathlib import Path

THU_MUC_DATA = Path("data")              
THU_MUC_OUTPUT = Path("data_train")      
THU_MUC_OUTPUT.mkdir(parents=True, exist_ok=True)

def doc_file_an_toan(duong_dan):
    du_lieu = []
    try:
        with open(duong_dan, 'r', encoding='utf-8') as f:
            if str(duong_dan).endswith('.jsonl'):
                for dong in f:
                    dong = dong.strip()
                    if dong:
                        du_lieu.append(json.loads(dong))
                return du_lieu

            noidung = json.load(f)
            if isinstance(noidung, list):
                du_lieu = noidung       
            elif isinstance(noidung, dict):
                du_lieu = [noidung]     
                
    except json.JSONDecodeError:
        du_lieu = []
        with open(duong_dan, 'r', encoding='utf-8') as f:
            for dong in f:
                dong = dong.strip()
                if dong:
                    try:
                        du_lieu.append(json.loads(dong))
                    except:
                        pass
    except Exception as e:
        print(f"  - LỖI Không thể đọc {os.path.basename(duong_dan)}: {e}")
        
    return du_lieu

def main():
    thoi_gian_bat_dau = time.time()
    print("Bước 1: Nạp dữ liệu vào bộ nhớ tạm...")
    du_lieu_tong = []
    thong_ke_file = {}

    if not THU_MUC_DATA.exists():
        print(f"LỖI Không tìm thấy thư mục: {THU_MUC_DATA}")
        return

    for file_path in THU_MUC_DATA.iterdir():
        if file_path.suffix in ['.json', '.jsonl']:
            data_file = doc_file_an_toan(file_path)
            if data_file:
                so_mau = len(data_file)
                du_lieu_tong.extend(data_file)
                thong_ke_file[file_path.name] = so_mau
                print(f"  - Đã nạp {file_path.name}: {so_mau:,} mẫu")

    if not du_lieu_tong:
        return

    print("\nBước 2: Xây dựng bộ từ vựng (Không gộp chuỗi lớn)...")
    cac_ky_tu = set()
    for mau in du_lieu_tong:
        vb = mau.get("van_ban", mau.get("text", ""))
        if vb:
            cac_ky_tu.update(vb)
            cac_ky_tu.add("\n") 

    cac_ky_tu = sorted(list(cac_ky_tu))
    kich_thuoc_tu_vung = len(cac_ky_tu)
    
    stoi = {ch: i for i, ch in enumerate(cac_ky_tu)}
    
    vocab_path = THU_MUC_OUTPUT / "vocab.json"
    with open(vocab_path, 'w', encoding='utf-8') as f:
        json.dump(stoi, f, ensure_ascii=False, indent=2)
    print(f"  - Kích thước từ vựng: {kich_thuoc_tu_vung} ký tự")

    print("\nBước 3: Mã hóa và Ghi trực tiếp ra ổ cứng (Chống tràn RAM)...")
    random.shuffle(du_lieu_tong)
    
    train_bin_path = THU_MUC_OUTPUT / "train.bin"
    val_bin_path = THU_MUC_OUTPUT / "val.bin"
    
    tong_token = 0
    token_train = 0
    token_val = 0
    so_luong_mau = len(du_lieu_tong)

    with open(train_bin_path, 'wb') as f_train, open(val_bin_path, 'wb') as f_val:
        for i, mau in enumerate(du_lieu_tong):
            vb = mau.get("van_ban", mau.get("text", ""))
            if not vb:
                continue
            vb += "\n"
            
            ids = [stoi[c] for c in vb if c in stoi]
            arr = np.array(ids, dtype=np.uint16)
            
            if random.random() < 0.9:
                f_train.write(arr.tobytes())
                token_train += len(ids)
            else:
                f_val.write(arr.tobytes())
                token_val += len(ids)
                
            tong_token += len(ids)
            
            if (i + 1) % 200000 == 0 or (i + 1) == so_luong_mau:
                tien_do = (i + 1) / so_luong_mau * 100
                print(f"  Đã xử lý {i + 1:,} / {so_luong_mau:,} mẫu ({tien_do:.1f}%)")

    print("\nBước 4: Lưu tệp tổng hợp và kết luận...")
    tong_hop_path = THU_MUC_OUTPUT / "du_lieu_tong_hop.json"
    with open(tong_hop_path, 'w', encoding='utf-8') as f:
        json.dump(du_lieu_tong, f, ensure_ascii=False, indent=2)

    thong_ke_path = THU_MUC_OUTPUT / "thong_ke_du_lieu.json"
    thong_ke_cuoi = {
        "tong_so_mau": so_luong_mau,
        "tong_so_token": tong_token,
        "token_train": token_train,
        "token_val": token_val,
        "vocab_size": kich_thuoc_tu_vung,
        "chi_tiet_file": thong_ke_file
    }
    with open(thong_ke_path, 'w', encoding='utf-8') as f:
        json.dump(thong_ke_cuoi, f, ensure_ascii=False, indent=2)

    thoi_gian_chay = time.time() - thoi_gian_bat_dau
    print(f"  - train2.bin: {token_train:,} mã thông báo")
    print(f"  - val2.bin:   {token_val:,} mã thông báo")
    print(f"  - Tổng mã thông báo : {tong_token:,} mã thông báo")
    print(f"\nHoàn tất toàn bộ trong: {thoi_gian_chay:.1f} giây!")

if __name__ == "__main__":
    main()